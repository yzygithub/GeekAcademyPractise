<?php
    header("Content-type:application/json;charset:utf-8");
    $link = mysqli_connect('localhost','root','','newsdb',3306);
?>