angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('CartCtrl', function($scope) {
  $scope.goodsChecked=[];
  $scope.cartList=[
    { id:0,
      image:"../img/goods2.jpg",
      name:"东芝（TOSHIBA） 32GB 90MB/s TF(micro SD)存储卡 UHS-I U3 Class10 高速存储卡（新老包装随机发货）",
      price:81.90,
      weight:0.1
    },
    { id:1,
      image:"../img/goods3.jpg",
      name:"画醉 2017春装新款牛仔裤-4.11DZH 浅蓝色 L",
      price:118.90,
      weight:0.5
    },
    { id:2,
      image:"../img/goods1.jpg",
      name:"外星人（Alienware）452-BBRT Alienware Graphic Amplifier 显卡扩展坞",
      price:2199.00,
      weight:0.1
    },
    { id:3,
      image:"../img/goods4.jpg",
      name:"Apple MacBook Pro 15.4英寸笔记本电脑 银色(Core i7 处理器/16GB内存/256GB SSD闪存/Retina屏 MJLQ2CH/A)",
      price:13688.00,
      weight:1.5
    }
  ];
  $scope.settings = {
    enableFriends: true
  };
  $scope.selectFlag=false;

  $scope.addGoods = function (item) { //添加商品到购物车
    var index = $scope.goodsChecked.indexOf(item);

    if (index != -1) {  //检查商品是否已经添加到购物车中
      item.count = ++$scope.goodsChecked[index].count;
      item.isDisabled = false;
    }
    else {
      item.count = 0;
      item.count++; //加入购物车后，购物车中该商品数量默认为1
      item.isDisabled = true;
      if ($scope.toEdit == false) {
        item.checked = true;
        $scope.selcetAll = true;
      }
      else {
        item.checked = false;
        $scope.selcetAll = false;
      }
      $scope.goodsChecked.push(item);
    }
    $scope.account();
  }

  $scope.addCount = function (item) {  //增加单个商品数量
    item.singleTotal = 0; //每次计算需将单个商品的数值重置为零
    item.count++; // 购物车中单个货物数量

    if (item.count > 1) {
      item.isDisabled = false;
    }
    $scope.account();
  }

  $scope.decreaseCount = function (item) { //减少单个商品数量
    item.singleTotal = 0;
    item.count--;

    if (item.count == 1) {
      item.isDisabled = true;
    }
    $scope.account();
  }

  $scope.toggleChecked = function (item) {
    item.checked = !item.checked; //切换选择取消

    var a = 0; //统计选中的数量
    for (var i = 0; i < $scope.goodsChecked.length; i++) { //购物车中有未选中结算的商品，全选项即为未选中
      if ($scope.goodsChecked[i].checked == true) {
        a++;  //选中的个数
      }
    }
    if (a == $scope.goodsChecked.length) {
      $scope.selcetAll = true;
    } else {
      $scope.selcetAll = false;
    }
    if ($scope.toEdit == false) {
      $scope.account();
    }
  }

  $scope.checkAll = function () {  //全选，结算全部购物车中商品
    $scope.selcetAll = !$scope.selcetAll;
    for (var i = 0; i < $scope.goodsChecked.length; i++) {
      $scope.goodsChecked[i].checked = $scope.selcetAll;
    }
    $scope.account();
  }

  $scope.toEdit = false;
  $scope.editFunc = function () { //切换为编辑状态
    $scope.toEdit = true;
    $scope.preChecked = $scope.selcetAll;
    $scope.selcetAll = false;
    for (var i = 0; i < $scope.goodsChecked.length; i++) {
      $scope.goodsChecked[i].preChecked = $scope.goodsChecked[i].checked;
      $scope.goodsChecked[i].checked = false;
    }
  }

  $scope.okFunc = function () { //退出编辑状态
    var a = 0;
    $scope.toEdit = false;
    for (var i = 0; i < $scope.goodsChecked.length; i++) {
      $scope.goodsChecked[i].checked = $scope.goodsChecked[i].preChecked;
      if ($scope.goodsChecked[i].checked == true) {
        a++;
      }
    }

    if (a == $scope.goodsChecked.length && $scope.goodsChecked.length != 0) {
      $scope.selcetAll = true;
    }
    $scope.account();
  }

  $scope.deleteGood = function () { //编辑状态下删除被选中的商品
    if ($scope.toEdit == true && $scope.goodsChecked.length > 0) {
      for (var i = 0; i < $scope.goodsChecked.length; i++) {
        if ($scope.goodsChecked[i].checked == true) {
          $scope.goodsChecked.splice($scope.goodsChecked.indexOf($scope.goodsChecked[i]), 1);
          i--;//因为删除了一项，$scope.goodsChecked的长度就减少了一个
        }
        if ($scope.goodsChecked.length == 0) {
          $scope.selcetAll = false;
        }
      }
    }

  }

  $scope.account = function () { //计算总价
    $scope.sum = 0;
    $scope.totalValue = 0;
    for (var i = 0; i < $scope.goodsChecked.length; i++) {
      $scope.goodsChecked[i].singleTotal = 0;
      if ($scope.goodsChecked[i].checked) {
        $scope.goodsChecked[i].singleTotal = $scope.goodsChecked[i].price * $scope.goodsChecked[i].count; //单个商品的总价格
        $scope.sum += $scope.goodsChecked[i].count; //计算总数量
      } else if ($scope.goodsChecked[i].checked == false) {
        $scope.goodsChecked[i].singleTotal = 0;
      }
      $scope.totalValue += $scope.goodsChecked[i].singleTotal; //计算总价
    }
  }

  $(document).ready(function () {
    //商品分类
    $('.layer_select li.classify').click(function () {
      $('.layer_select .selected').removeClass('selected');
      $(this).addClass('selected');
      if(!$(this).hasClass('allGoods')){
        $('.section').hide('500');
        $('.shopcart_empty').show('500')
      } else {
        $('.section').show('500');
        $('.shopcart_empty').hide('500')
      }
    });
    //购买
    // $(document).on('click','.buy',function () {
    //   $('.detail_sku_v1_main').fadeIn();
    //   console.log(this.goods);
    // });
    // $('.itemDetailClose').click(function () {
    //   $('.detail_sku_v1_main').hide()
    // });
    //编辑商品
    // $('#editBtn').click(function () {
    //   if($(this).hasClass('clicked')){
    //     $('#operateDiv').hide();
    //     $('#totalConfirmDiv').show();
    //     $('#editBtn>span').text('编辑商品');
    //     $(this).removeClass('clicked');
    //   } else {
    //     $('#totalConfirmDiv').hide();
    //     $('#operateDiv').show();
    //     $('#editBtn>span').text('完成');
    //     $(this).addClass('clicked');
    //     $('.icon_select').parent().removeClass('selected');
    //   }
    // });
//  勾选
    $(document).on('click','.head .icon_select',function () {
      if($(this).parent().hasClass('selected')){
        $('.section .icon_select').parent().removeClass('selected')
      }else {
        $('.section .icon_select').parent().addClass('selected')
      }
    })
    $(document).on('click','.goods .icon_select',function() {
      if($(this).parent().hasClass('selected')){
        $(this).parent().removeClass('selected')
      }else {
        $(this).parent().addClass('selected')
      }
    })
    $(document).on('click','.fixBar .icon_select',function () {
      if($(this).parent().hasClass('selected')){
        $('#listContent .icon_select').parent().removeClass('selected');
        $(this).parent().removeClass('selected');
      } else {
        $('#listContent .icon_select').parent().addClass('selected');
        $(this).parent().addClass('selected');
      }
    })
    $(document).on('click','#editBtn',function () {
      $('.icon_select').parent().removeClass('selected');
    })
  });

});
