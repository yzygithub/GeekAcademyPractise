npm init
npm install --save-dev gulp
npm install node-sass --save-dev
npm install gulp-sass --save-dev
npm install gulp-autoprefixer