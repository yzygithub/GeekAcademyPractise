[经典案例训练]：青岛家教网注册页面是一个N年前非常传统的老式页面，很陈旧，需要大家用自己新学过的HTML&HTML5&CSS&CSS3的知识，一些新的表单元素，重新实现和改良这个页面，达到熟悉表单元素的目的（传统input和H5的混用达到全部熟悉的目的）。
具体要制作的页面，入口在http://www.qdjj.net/member/register_1.asp（不需要做），先填写一些资料后进入下一个页面（http://www.qdjj.net/member/register_2.asp）就是我们需要制作的。作业量比较大，做完会有很大收获！大家加油！
其它参见【解题提示】


v1 重构了页面，内容和样式分离。
v2 添加了label标签（部分），使用了required和placeholder属性（部分）
v3 删除重复id属性。