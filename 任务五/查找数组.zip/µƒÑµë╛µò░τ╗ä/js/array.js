/**
 * Created by yzy on 2017/4/24.
 */
var array = ['a', 'x', 'b', 'd', 'm', 'a', 'k', 'm', 'p', 'j', 'a'];
//计数
var count = {};
//索引
var position = {};
//遍历原数组并且生成新数组
function arraySearch() {

  for (var i = 0; i < array.length; i++) {
    var char = array[i];
    if (count[char]) {
      count[char] += 1;
      position[char] += ',' + i;
    } else {
      count[char] = 1;
      position[char] = i;
    }
  }

//返回出现次数最多的字母的次数（降序排列后取第一个数字）
  var max = count[Object.keys(count).sort(function (a, b) {
    return count[a] <= count[b];
  })[0]];

//出现次数最多的字母如果有多个，全部写入arrayOutput数组中，并输出
  var arrayOutput = [];

  for (i in count) {
    if (count[i] >= max) {
      //将最大值给max
      max = count[i];
      //将出现最多的字母放到arrayOutput数组中
      arrayOutput.push(i);
      console.log(arrayOutput)
    }
  }

//将出现最多的字母的次数输出
  for (var i = 0; i < arrayOutput.length; i++) {
    key = arrayOutput[i];
    document.getElementById('output').innerHTML = '出现次数最多的字母是:' + arrayOutput + '<br>' + key + '出现的次数为:' + count[key] + '<br>' + key + '的位置分别为:' + position[key] + '<br>';
  }

}